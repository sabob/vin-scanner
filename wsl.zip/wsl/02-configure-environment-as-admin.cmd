@schtasks /Create /F /XML C:\Windows\Temp\scheduled-task.xml /TN ConfigureWSLAdapter
@pause
@del "C:\Windows\Temp\scheduled-task.xml"
