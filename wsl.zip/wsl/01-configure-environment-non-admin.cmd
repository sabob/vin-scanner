@xcopy /q /y .\tools\configure-wsl-adapter.cmd %USERPROFILE%\AppData\Local\Tradein-Dev\ && echo Network adapter configuration script copied
@echo. 
@xcopy /q /y .\tools\px.exe %USERPROFILE%\AppData\Local\Tradein-Dev\ && @%USERPROFILE%\AppData\Local\Tradein-Dev\px.exe --install
@echo.       
@xcopy /q /y .\tools\Tradein-Dev.lnk %USERPROFILE%\Desktop\ && echo Shortcut copied to desktop
@echo. 
@powershell -Command "(Get-Content -Path '.\tools\scheduled-task.xml') -replace 'TRADEIN_DEV_DIRECTORY','%USERPROFILE%\AppData\Local\Tradein-Dev'" > "C:\Windows\Temp\scheduled-task.xml" && echo Scheduled task import file copied
@echo. 
@pause
