netsh interface portproxy reset
netsh.exe interface ipv4 add address "vEthernet (WSL)" 169.254.254.1/30
timeout 7 /nobreak
netsh.exe interface portproxy set v4tov4 listenaddress=169.254.254.1 listenport=3128 connectaddress=127.0.0.1 connectport=3128
