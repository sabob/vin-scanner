https://atc.bmwgroup.net/confluence/display/DVSS/Local+Development+Environment
